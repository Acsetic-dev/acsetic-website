const products = [
  {name:"Dried Moringa Leaves",cat:"Herbs & botanicals",price:2500,emoji:"🍃",desc:"Dried botanical leaves. Sample listing."},
  {name:"Pure Shea Butter",cat:"Skincare",price:3200,emoji:"🧴",desc:"Unrefined shea butter. Sample listing."},
  {name:"Cold-Pressed Coconut Oil",cat:"Natural oils",price:4500,emoji:"🥥",desc:"Natural oil for external use. Sample listing."},
  {name:"Natural Honey",cat:"Natural foods",price:3800,emoji:"🍯",desc:"Packaged honey. Sample listing."},
  {name:"Dried Ginger",cat:"Herbs & botanicals",price:1800,emoji:"🫚",desc:"Dried ginger pieces. Sample listing."},
  {name:"African Black Soap",cat:"Skincare",price:2200,emoji:"🧼",desc:"Traditional black soap. Sample listing."},
  {name:"Moringa Seed Oil",cat:"Natural oils",price:5200,emoji:"🌱",desc:"Botanical oil. Sample listing."}
];
let cart = [];
const naira = n => "₦" + Number(n).toLocaleString("en-NG");

function renderProducts(){
  const q = document.getElementById("search").value.toLowerCase();
  const c = document.getElementById("categoryFilter").value;
  const s = document.getElementById("sort").value;
  let arr = products.filter(p => (!q || (p.name+" "+p.cat).toLowerCase().includes(q)) && (!c || p.cat===c));
  if(s==="low") arr.sort((a,b)=>a.price-b.price);
  if(s==="high") arr.sort((a,b)=>b.price-a.price);
  document.getElementById("products").innerHTML = arr.map(p => `
    <article class="product"><div class="product-art">${p.emoji}</div>
    <div class="product-body"><span class="pill">${p.cat}</span><h3>${p.name}</h3>
    <p>${p.desc}</p><div class="price">${naira(p.price)}</div>
    <button type="button" data-add="${p.name}">Add to cart</button></div></article>`).join("") || "<p>No matching products found.</p>";
}
function renderCart(){
  document.getElementById("cartCount").textContent = cart.length;
  document.getElementById("cartItems").innerHTML = cart.length
    ? cart.map((p,i)=>`<div class="cartline"><span>${p.name}</span><span>${naira(p.price)} <button type="button" data-remove="${i}" style="padding:4px 8px">×</button></span></div>`).join("")
    : "<p class='small'>Your cart is empty.</p>";
  document.getElementById("cartTotal").textContent = naira(cart.reduce((sum,p)=>sum+p.price,0));
}
function renderSubmissions(){
  const subs = JSON.parse(localStorage.getItem("acsetic_subs") || "[]");
  document.getElementById("submissions").innerHTML = subs.length
    ? subs.map((s,i)=>`<div class="cartline" style="align-items:center;flex-wrap:wrap">
        <span><b>${escapeHtml(s.product)}</b> — ${escapeHtml(s.seller)}<br>
        <span class="small">${escapeHtml(s.category)} • ${escapeHtml(s.location)} • ${escapeHtml(s.reg || "No registration number entered")}</span><br>
        <span class="pill">${s.status}</span></span>
        <span><button type="button" data-status="${i}|Approved">Approve</button>
        <button type="button" data-status="${i}|Rejected" style="background:#9b443d">Reject</button></span></div>`).join("")
    : "<p class='small'>No seller submissions yet.</p>";
}
function escapeHtml(value){
  return String(value).replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
}

document.getElementById("products").addEventListener("click", e => {
  const name = e.target.dataset.add;
  if(name){ const p = products.find(x=>x.name===name); if(p){cart.push(p);renderCart();} }
});
document.getElementById("cartItems").addEventListener("click", e => {
  const i = e.target.dataset.remove;
  if(i !== undefined){cart.splice(Number(i),1);renderCart();}
});
document.getElementById("search").addEventListener("input", renderProducts);
document.getElementById("searchButton").addEventListener("click", renderProducts);
document.getElementById("categoryFilter").addEventListener("change", renderProducts);
document.getElementById("sort").addEventListener("change", renderProducts);
document.getElementById("checkoutButton").addEventListener("click", () => alert("This is a demonstration only. Real checkout will be connected later."));

document.getElementById("sellerForm").addEventListener("submit", e => {
  e.preventDefault();
  const form = e.currentTarget;
  const data = new FormData(form);
  const submission = {
    seller:data.get("seller"), email:data.get("email"), phone:data.get("phone"),
    location:data.get("location"), product:data.get("product"), category:data.get("category"),
    price:data.get("price"), reg:data.get("reg"), description:data.get("description"), status:"Pending"
  };
  const subs = JSON.parse(localStorage.getItem("acsetic_subs") || "[]");
  subs.push(submission);
  localStorage.setItem("acsetic_subs", JSON.stringify(subs));
  document.getElementById("sellerMsg").textContent = "Submission received in this browser demo. Status: Pending review.";
  form.reset();
  renderSubmissions();
});
document.getElementById("submissions").addEventListener("click", e => {
  const value = e.target.dataset.status;
  if(!value) return;
  const [index,status] = value.split("|");
  const subs = JSON.parse(localStorage.getItem("acsetic_subs") || "[]");
  if(subs[Number(index)]){subs[Number(index)].status=status;localStorage.setItem("acsetic_subs",JSON.stringify(subs));renderSubmissions();}
});
document.getElementById("refreshButton").addEventListener("click", renderSubmissions);

renderProducts();
renderCart();
renderSubmissions();
